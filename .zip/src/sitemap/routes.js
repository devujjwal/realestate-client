const routes = ['/', '/advert/:id','/search/city/:cityName'];

export default routes;